using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public GameManager manager;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            manager.GameOver();
        }
    }
}