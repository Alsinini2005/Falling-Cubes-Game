using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject obstaclePrefab;
    public float spawnRange = 8f;
    public float spawnRate = 1.5f;

    void Start()
    {
        InvokeRepeating("SpawnObstacle", 1f, spawnRate);
    }

    void SpawnObstacle()
    {
        Vector3 pos = new Vector3(Random.Range(-spawnRange, spawnRange), 10, 0);
        Instantiate(obstaclePrefab, pos, Quaternion.identity);
    }
}
