using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 10f;
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float move = Input.GetAxis("Horizontal");
        Vector3 movement = new Vector3(move * speed, rb.linearVelocity.y, 0);
        rb.linearVelocity = movement;
    }
}