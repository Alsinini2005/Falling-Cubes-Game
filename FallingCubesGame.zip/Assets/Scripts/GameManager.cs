using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject gameOverPanel;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI finalScoreText;

    float score = 0f;
    bool gameEnded = false;

    void Update()
    {
        if (!gameEnded)
        {
            score += Time.deltaTime * 10;
            scoreText.text = "Score: " + Mathf.FloorToInt(score);
        }
    }

    public void GameOver()
    {
        gameEnded = true;

        gameOverPanel.SetActive(true);

        finalScoreText.text = "Final Score: " + Mathf.FloorToInt(score);

        Time.timeScale = 0f;
    }
}